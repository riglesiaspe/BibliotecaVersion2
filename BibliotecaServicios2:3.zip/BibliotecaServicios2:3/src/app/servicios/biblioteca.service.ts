import { Injectable } from '@angular/core';

import { AngularFirestore } from '@angular/fire/firestore';

import { Facultad } from '../modelos/facultad.model'; 
import { Grado } from '../modelos/grado.model';
import { Curso } from '../modelos/curso.model';
import { Asignatura } from '../modelos/asignatura.model';
import { Listadocitas } from '../modelos/listadocitas.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BibliotecaService {
  
/*
  facultades= [   {"id":"1","name":"Ciencias de la Salud"},
                  {"id":"2","name":"Comunicación"},
                  {"id":"3","name":"Derecho Canónico"},
                  {"id":"4","name":"Educación"},
                  {"id":"5","name":"Filosofía"},
                  {"id":"6","name":"Informática", "grados": [
                                                              {"id":"1","titulo":"Administración y Dirección de Empresas Tecnológicas", "cursos": [
                                                                                                                                                      {"curso": "primero", "asignaturas": [
                                                                                                                                                                                              {"codigo":"102511004" ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                                          {"listadocitas": "Experto en Transformación e Impulso de Empresas. Comunicación en la empresa", "ejemplares":"6", "url":"https://koha.upsa.es/cgi-bin/koha/opac-shelves.pl?op=view&shelfnumber=1222"},
                                                                                                                                                                                                                                                                                                          {"listadocitas": "Experto en Transformación e Impulso de Empresas. Impulso de empresas", "ejemplares":"6", "url":"https://koha.upsa.es/cgi-bin/koha/opac-shelves.pl?op=view&shelfnumber=1720"},
                                                                                                                                                                                                                                                                                                          {"listadocitas": "Experto en Transformación en Impulso de Empresas. Transformación de empresas mediante el uso de la tecnología", "ejemplares":"3", "url":"https://koha.upsa.es/cgi-bin/koha/opac-shelves.pl?op=view&shelfnumber=809"},
                                                                                                                                                                                                                                                                                                          {"listadocitas": "F. Informática. ADET. Creación de empresas", "ejemplares":"3", "url":"https://koha.upsa.es/cgi-bin/koha/opac-shelves.pl?op=view&shelfnumber=1228"}
                                                                                                                                                                                                                                                                                                      ]},
                                                                                                                                                                                              {"codigo":"102520002" ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                                              {"codigo":"102511002" ,"asignatura": "Historia Económica"},
                                                                                                                                                                                              {"codigo":"102513004" ,"asignatura": "Inglés"},
                                                                                                                                                                                              {"codigo":"102511001" ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                                              {"codigo":"102511003" ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                                              {"codigo":"102520001" ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                                              {"codigo":"102512001" ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                                              {"codigo":"102511005" ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                                              {"codigo":"102511006" ,"asignatura": "Microeconomía"}
                                                                                                                                                                                          ]},
                                                                                                                                                      {"curso": "segundo"},
                                                                                                                                                      {"curso": "tercero"},
                                                                                                                                                      {"curso": "cuarto"}  
                                                                                                                                                  ] },
                                                              {"id":"2","titulo":"Ingeniería Informática", "cursos": [
                                                                                                                      {"curso": "primero"},
                                                                                                                      {"curso": "segundo"},
                                                                                                                      {"curso": "tercero"},
                                                                                                                      {"curso": "cuarto"}
                                                                                                                    ] },                  
                                                              {"id":"3","titulo":"Informática Móvil", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":401860001 ,"asignatura": "Tecnologías del lado del cliente: HTML5", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":401860002 ,"asignatura": "Tecnologías del lado del Servidor: Cloud computing"},
                                                                                                                                                                          {"codigo":401860003 ,"asignatura": "Desarrollo de aplicaciones iOS"},
                                                                                                                                                                          {"codigo":401860004 ,"asignatura": "Desarrollo de aplicaciones Android"},
                                                                                                                                                                          {"codigo":401860006 ,"asignatura": "Desarrollo de aplicaciones cross-platform"},
                                                                                                                                                                          {"codigo":401870001 ,"asignatura": "Prácticas en empresas"},
                                                                                                                                                                          {"codigo":401870002 ,"asignatura": "Tendencias en el desarrollo de apps"},
                                                                                                                                                                          {"codigo":401890001 ,"asignatura": "Trabajo Fin de Master"}
                                                                                                                                                                      ]}
                                                                                                                ]},
                                                              {"id":"4","titulo":"Dirección de Proyectos Informáticos y Servicios Tecnológicos", "cursos": [
                                                                                                                                                                          {"curso": "primero"},
                                                                                                                                                                          {"curso": "segundo"},
                                                                                                                                                                          {"curso": "tercero"},
                                                                                                                                                                          {"curso": "cuarto"}
                                                                                                                                                            ]},
                                                              {"id":"5","titulo":"Big Data y Analystics", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                    ]},
                                                              {"id":"6","titulo":"Programación iOS", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                ]},
                                                              {"id":"7","titulo":"Programación Android", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                  ]},
                                                              {"id":"8","titulo":"Big Data", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                        ]},
                                                              {"id":"9","titulo":"SAP Business One", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                ]},
                                                              {"id":"10","titulo":"Transformación e impulso de empresas", "cursos": [
                                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                                  ]},
                                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                                      ]},
                                                                                                                                                  {"curso": "segundo"},
                                                                                                                                                  {"curso": "tercero"},
                                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                                    ]}
                                                            ] },
                  {"id":"7","name":"Psicología", "grados": [
                                                                {"id":1,"titulo":"PsicologiaPrueba", "cursos": [
                                                                                                                {"curso": "primero", "asignaturas": [
                                                                                                                                                        {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                    {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                    {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                ]},
                                                                                                                                                        {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                        {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                        {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                        {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                        {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                        {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                        {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                        {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                        {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                    ]},
                                                                                                                {"curso": "segundo"},
                                                                                                                {"curso": "tercero"},
                                                                                                                {"curso": "cuarto"}  
                                                                                                          ]}
                                                          ]},
                  {"id":"8","name":"Teología"},
                  {"id":"9","name":"Enfermería y Fisioterapia"},
                  {"id":"10","name":"Ciencias del Seguro, Jurídicas y de la Empresa"}
];
*/

//bibliotecaservice-bb52a.web.app

  identificadorfacultad;
  identificadorgrado;
  identificadorcurso;
  identificadorasignatura;

  facultad;
  grado;
  curso;

  //listaFacultades: Facultad[];

  constructor( private firestore: AngularFirestore ) { }

  obtenerFacultades(): Observable<any[]>
  {
    //return this.facultades;
    return this.firestore.collection('facultadesbiblioteca').snapshotChanges();
  }

  anadirFacultad(facultad: Facultad){
    let nuevaFacultad = Object.assign( {}, {'name': facultad });
    return this.firestore.collection('facultadesbiblioteca').add(nuevaFacultad);
  }

  eliminarFacultad(facultad:Facultad){
    this.firestore.doc('facultadesbiblioteca/' + facultad.id).delete();
    // O también
    //this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad).delete(); esto se puede hacer en cualquier eliminar menos en 
    //el último de listados ya que no he guardado su identificador, entonces si necesitaria los modelos
    // this.firestore.collection('facultadesbiblioteca').doc(facultad.id).delete();
  }

/* esto lo usaba cuando la bbdd era en local, como ahora esta en remoto en firebase, se hace directamente
  obtenerFacultad(id)
  {
    //this.identificadorfacultad = id;  //lo usaré para paginas más adelante, por ejemplo para conseguir los cursos de un grado concreto, de una facultad concreta, cuando voy de la pagina principal..
    //.. de facultades a una facultad concreta, me guardaba su id en la url, pero claro, en las siguientes paginas, la url cambia, y perdería el id para mostrar las asignaturas, cursos, grados, etc..
    //.. de una facultad con un id concreto, entonces, me estoy guardando este id en la variable identificadorfacultad de cara a futuras funciones.
    //return this.facultades.find( facultad => facultad.id === this.identificadorfacultad);
  
    this.identificadorfacultad = id;
    return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad).snapshotChanges();
  }
*/


  obtenerGrados(id): Observable<any[]>
  {
    //return facultad.grados;
    //yo antes ponia obtenerGrados(facultad),es decir le pasaba la facultad obtenida y a partir de ella pillaba sus grados,
    //pero ahora con firestone le puedo decir que ubique esa facultad directamente con su codigo
    this.identificadorfacultad = id;
    return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad).collection('grados').snapshotChanges();
  }

  anadirGrado(grado: Grado){
    let nuevoGrado = Object.assign( {}, {'titulo': grado });
    return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad).collection('grados').add(nuevoGrado);
  }

  eliminarGrado(grado:Grado){
    this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + grado.id).delete();
  }



//esto lo quiero para obtener un grado concreto y así poder mostrar los cursos que tiene dentro, no confundir el id del grado con el id de la facultad determinada.
//en principio con firebase esta función ya quedaría obsoleta, por que puedo coger los cursos directamente sin pasar por esta función, aunque necesito el id
  /*
obtenerGrado(id)
  {
    //this.identificadorgrado = id;
    //this.facultad = this.obtenerFacultad(this.identificadorfacultad);
    //return this.facultad.grados.find( grado => grado.id === this.identificadorgrado);

    this.identificadorgrado = id;
    return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado).snapshotChanges();
  }
  */

  obtenerCursosGrado(id): Observable<any[]>
  {
    //return grado.cursos;   antes ponia en obtenerCursosGRado(grado) pero ya no es necesario porque puedo cogerlo directamente
    this.identificadorgrado = id;
    return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado).collection('cursos').snapshotChanges();
  }

  anadirCurso(curso: Curso){
    let nuevoCurso = Object.assign( {}, {'curso': curso });
    return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado).collection('cursos').add(nuevoCurso);
  }

  eliminarCurso(curso:Curso){
    this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + curso.id).delete();
  }


//ahora quiero obtener un curso del grado y facultad concretos, para así poder mostrar sus asignaturas
//en principio esta función solo sirve para pasar el identificador de la url porque ya esta obsoleta
/*
obtenerCurso(id)
{
  //this.identificadorcurso = id;
  //this.grado = this.obtenerGrado(this.identificadorgrado);
  //return this.grado.cursos.find( curso => curso.curso === this.identificadorcurso);

  this.identificadorcurso = id;
  return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso).snapshotChanges();
}
*/

obtenerAsignaturas(id): Observable<any[]>
{
  //return curso.asignaturas; he quitado el obtenerAsignaturas(curso) ya no es necesario porque firestore lo hace directamente en una linea
  this.identificadorcurso = id;
  return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso).collection('asignaturas').snapshotChanges();
}

anadirAsignatura(asignatura, codigo){
  let nuevaAsignatura = Object.assign( {}, {'asignatura': asignatura ,'codigo': codigo});
  return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso).collection('asignaturas').add(nuevaAsignatura);
}

eliminarAsignatura(asignatura:Asignatura){
  this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + asignatura.id).delete();
}

buscarAsignatura(asignaturaBuscada:string): Observable<any>
{
  //esto no me está funcionando porque al pasarle una ruta con la asignatura buscada realmente no me coge el elemento asignatura ya que en firebase la url
  //de un elemento se muestra a través del id automático creado, por lo tanto cuando hago el buscador con el subscribe  en buscador.ts no obtengo nada
return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + asignaturaBuscada).snapshotChanges();
}



//quiero obtener una asignatura para una facultad, grado y curso determinada y así obtener sus listados de citas
/*
obtenerAsignatura(id)
{
  //this.curso = this.obtenerCurso(this.identificadorcurso);
  //return this.curso.asignaturas.find( asignatura => asignatura.codigo === codigo);
  this.identificadorasignatura = id;
  return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + this.identificadorasignatura).snapshotChanges();
}
*/

obtenerListadoscitas(id): Observable<any[]>
{
  this.identificadorasignatura = id;
  //le he quitado asignatura a la funcion porque ya no es util
  //return asignatura.listadoscitas;
  return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + this.identificadorasignatura).collection('listadoscitas').snapshotChanges();
}

anadirListado(listado, ejemplares, url){
  let nuevoListado = Object.assign( {}, {'listadocitas': listado ,'ejemplares': ejemplares, 'url':url});
  return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + this.identificadorasignatura).collection('listadoscitas').add(nuevoListado);
}

eliminarListado(listadocitas:Listadocitas){
  this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + this.identificadorasignatura + '/listadoscitas/' + listadocitas.id).delete();
}




}
