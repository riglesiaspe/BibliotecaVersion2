import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PrincipalComponent } from './paginas/principal/principal.component';
import { FacultadesComponent } from './componentes/facultades/facultades.component';
import { PaginaGradosComponent } from './paginas/pagina-grados/pagina-grados.component';
import { PaginaCursosComponent } from './paginas/pagina-cursos/pagina-cursos.component';
import { PaginaAsignaturasComponent } from './paginas/pagina-asignaturas/pagina-asignaturas.component';
import { PaginaListadoscitasComponent } from './paginas/pagina-listadoscitas/pagina-listadoscitas.component';


const routes: Routes = [
{ path: '', component: PrincipalComponent},
{ path: 'facultades/', component: FacultadesComponent},
{ path: 'paginagrados/:id', component: PaginaGradosComponent},
{ path: 'paginacursos/:id', component: PaginaCursosComponent},
{ path: 'paginasignaturas/:id', component: PaginaAsignaturasComponent},
{ path: 'paginalistadoscitas/:id', component: PaginaListadoscitasComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
