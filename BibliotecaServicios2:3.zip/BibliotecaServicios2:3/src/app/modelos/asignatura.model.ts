import { ListadoscitasComponent } from "../componentes/listadoscitas/listadoscitas.component";

export class Asignatura {
    id: String;
    codigo: String;
    asignatura: String;
    //listadoscitas: Listadocitas[];
}
