export class Listadocitas {
    id: String;
    listadocitas: String;
    ejemplares: String;
    url: String;
}
