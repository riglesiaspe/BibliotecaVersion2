import { Facultad } from './facultad.model';

describe('Facultad', () => {
  it('should create an instance', () => {
    expect(new Facultad()).toBeTruthy();
  });
});
