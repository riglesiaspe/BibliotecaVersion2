export class Facultad {
    id: string;
    name: string;
    //grados: Grado[];
    //aquí tendría que poner que hay un array dentro??
}
