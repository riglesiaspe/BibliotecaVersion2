export class Curso {
    id: String;
    curso: String;
    //asignaturas: Asignatura[];
}
