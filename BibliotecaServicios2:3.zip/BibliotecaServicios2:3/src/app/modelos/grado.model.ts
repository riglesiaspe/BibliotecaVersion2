export class Grado {
    id: String;
    titulo: String;
    // cursos: Curso[];
}
