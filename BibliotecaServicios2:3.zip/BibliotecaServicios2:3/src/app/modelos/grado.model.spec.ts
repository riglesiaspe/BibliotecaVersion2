import { Grado } from './grado.model';

describe('Grado', () => {
  it('should create an instance', () => {
    expect(new Grado()).toBeTruthy();
  });
});
