import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-asignaturas',
  templateUrl: './pagina-asignaturas.component.html',
  styleUrls: ['./pagina-asignaturas.component.css']
})
export class PaginaAsignaturasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
