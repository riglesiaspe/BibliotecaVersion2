import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-listadoscitas',
  templateUrl: './pagina-listadoscitas.component.html',
  styleUrls: ['./pagina-listadoscitas.component.css']
})
export class PaginaListadoscitasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
