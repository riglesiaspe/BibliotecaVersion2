import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-grados',
  templateUrl: './pagina-grados.component.html',
  styleUrls: ['./pagina-grados.component.css']
})
export class PaginaGradosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
