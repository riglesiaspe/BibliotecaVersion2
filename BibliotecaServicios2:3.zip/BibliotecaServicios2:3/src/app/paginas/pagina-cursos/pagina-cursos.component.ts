import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-cursos',
  templateUrl: './pagina-cursos.component.html',
  styleUrls: ['./pagina-cursos.component.css']
})
export class PaginaCursosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
