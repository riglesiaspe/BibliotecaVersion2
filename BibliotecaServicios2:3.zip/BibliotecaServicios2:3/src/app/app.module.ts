import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AngularFireModule } from '@angular/fire';
import { environment } from 'src/environments/environment';
import { AngularFireDatabaseModule } from '@angular/fire/database';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FacultadesComponent } from './componentes/facultades/facultades.component';
import { PaginaGradosComponent } from './paginas/pagina-grados/pagina-grados.component';
import { GradosComponent } from './componentes/grados/grados.component';
import { PrincipalComponent } from './paginas/principal/principal.component';
import { PaginaCursosComponent } from './paginas/pagina-cursos/pagina-cursos.component';
import { CursosComponent } from './componentes/cursos/cursos.component';
import { PaginaAsignaturasComponent } from './paginas/pagina-asignaturas/pagina-asignaturas.component';
import { AsignaturasComponent } from './componentes/asignaturas/asignaturas.component';
import { PaginaListadoscitasComponent } from './paginas/pagina-listadoscitas/pagina-listadoscitas.component';
import { ListadoscitasComponent } from './componentes/listadoscitas/listadoscitas.component';
import { FacultadNuevaComponent } from './componentes/facultad-nueva/facultad-nueva.component';
import { GradoNuevoComponent } from './componentes/grado-nuevo/grado-nuevo.component';
import { CursoNuevoComponent } from './componentes/curso-nuevo/curso-nuevo.component';
import { AsignaturaNuevaComponent } from './componentes/asignatura-nueva/asignatura-nueva.component';
import { ListadocitasNuevoComponent } from './componentes/listadocitas-nuevo/listadocitas-nuevo.component';
import { FooterComponent } from './componentes/footer/footer.component';
import { HeaderNaranjaComponent } from './componentes/header-naranja/header-naranja.component';
import { BuscadorComponent } from './componentes/buscador/buscador.component';


@NgModule({
  declarations: [
    AppComponent,
    FacultadesComponent,
    PaginaGradosComponent,
    GradosComponent,
    PrincipalComponent,
    PaginaCursosComponent,
    CursosComponent,
    PaginaAsignaturasComponent,
    AsignaturasComponent,
    PaginaListadoscitasComponent,
    ListadoscitasComponent,
    FacultadNuevaComponent,
    GradoNuevoComponent,
    CursoNuevoComponent,
    AsignaturaNuevaComponent,
    ListadocitasNuevoComponent,
    FooterComponent,
    HeaderNaranjaComponent,
    BuscadorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireDatabaseModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
