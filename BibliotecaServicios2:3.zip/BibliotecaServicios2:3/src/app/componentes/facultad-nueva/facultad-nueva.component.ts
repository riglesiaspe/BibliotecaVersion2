import { Component, OnInit } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';


@Component({
  selector: 'app-facultad-nueva',
  templateUrl: './facultad-nueva.component.html',
  styleUrls: ['./facultad-nueva.component.css']
})
export class FacultadNuevaComponent implements OnInit {

  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }
  anadirFacultad(facultad){
    this.bibliotecaService.anadirFacultad(facultad.value);
    facultad.value="";
  }

}
