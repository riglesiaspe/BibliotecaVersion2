import { Component, OnInit } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-asignatura-nueva',
  templateUrl: './asignatura-nueva.component.html',
  styleUrls: ['./asignatura-nueva.component.css']
})
export class AsignaturaNuevaComponent implements OnInit {

  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }

  anadirAsignatura(asignatura, codigo){
    this.bibliotecaService.anadirAsignatura(asignatura.value, codigo.value);
    asignatura.value="";
    codigo.value="";
  }
}
