import { Component, OnInit, Input } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-asignaturas',
  templateUrl: './asignaturas.component.html',
  styleUrls: ['./asignaturas.component.css']
})
export class AsignaturasComponent implements OnInit {

  id;
  curso;
  listasignaturas;

  @Input() asignatura;

  constructor( private bibliotecaService: BibliotecaService,
    private route: ActivatedRoute,
    private location: Location ) { }

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id']; //para obtener el parametro curso que había pasado en la URL

    //this.curso=this.bibliotecaService.obtenerCurso(this.cursourl);

    /*
    this.bibliotecaService.obtenerCurso(this.id)
    .subscribe( curso => {
      this.curso = curso.payload.data()
      });
    */
    



    //this.listasignaturas=this.bibliotecaService.obtenerAsignaturas(this.curso);


    this.bibliotecaService.obtenerAsignaturas(this.id)
    .subscribe( asignaturas => {
      this.listasignaturas = asignaturas.map (a => {
        return {
          id: a.payload.doc.id,
          ...a.payload.doc.data()
        };
      });
    });
  }

  eliminarAsignatura(asignatura){
    this.bibliotecaService.eliminarAsignatura(asignatura);
  }

}
