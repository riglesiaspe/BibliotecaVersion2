import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadocitasNuevoComponent } from './listadocitas-nuevo.component';

describe('ListadocitasNuevoComponent', () => {
  let component: ListadocitasNuevoComponent;
  let fixture: ComponentFixture<ListadocitasNuevoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListadocitasNuevoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadocitasNuevoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
