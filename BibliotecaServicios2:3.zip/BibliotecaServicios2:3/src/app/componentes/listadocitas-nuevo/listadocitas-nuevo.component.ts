import { Component, OnInit } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-listadocitas-nuevo',
  templateUrl: './listadocitas-nuevo.component.html',
  styleUrls: ['./listadocitas-nuevo.component.css']
})
export class ListadocitasNuevoComponent implements OnInit {

  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }

  anadirListado(listado, ejemplares, url){
    this.bibliotecaService.anadirListado(listado.value, ejemplares.value, url.value);
    listado.value="";
    ejemplares.value="";
    url.value="";
  }
}
