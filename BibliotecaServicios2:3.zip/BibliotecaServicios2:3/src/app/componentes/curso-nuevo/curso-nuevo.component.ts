import { Component, OnInit } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-curso-nuevo',
  templateUrl: './curso-nuevo.component.html',
  styleUrls: ['./curso-nuevo.component.css']
})
export class CursoNuevoComponent implements OnInit {

  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }

  anadirCurso(curso){
    this.bibliotecaService.anadirCurso(curso.value);
    curso.value="";
  }
}
