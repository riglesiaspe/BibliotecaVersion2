import { Component, OnInit, Input } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-facultades',
  templateUrl: './facultades.component.html',
  styleUrls: ['./facultades.component.css']
})
export class FacultadesComponent implements OnInit {

  listaFacultades;
  @Input() facultad;

  constructor( private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
   // this.listaFacultades=this.bibliotecaService.obtenerFacultades();
  this.bibliotecaService.obtenerFacultades()
  .subscribe( facultades => {
    this.listaFacultades = facultades.map (f => {
      return {
        id: f.payload.doc.id,
        ...f.payload.doc.data()
      };
    });
  });
  }

  eliminarFacultad(facultad){
    this.bibliotecaService.eliminarFacultad(facultad);
  }

}
