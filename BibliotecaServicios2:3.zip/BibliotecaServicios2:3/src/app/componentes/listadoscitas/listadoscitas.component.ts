import { Component, OnInit, Input } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-listadoscitas',
  templateUrl: './listadoscitas.component.html',
  styleUrls: ['./listadoscitas.component.css']
})
export class ListadoscitasComponent implements OnInit {

  id;
  asignatura;
  listaslistadoscitas;

  @Input() listadocitas;

  constructor( private bibliotecaService: BibliotecaService,
    private route: ActivatedRoute,
    private location: Location ) { }

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id']; //para obtener el parametro codigo que había pasado en la URL de cada asignatura

    //this.asignatura=this.bibliotecaService.obtenerAsignatura(this.codigo);
    

    /*
      this.bibliotecaService.obtenerAsignatura(this.id)
      .subscribe( asignatura => {
        this.asignatura = asignatura.payload.data()
        });
      
    */
  
  
      //this.listaslistadoscitas=this.bibliotecaService.obtenerListadoscitas(this.asignatura);
  
  
      this.bibliotecaService.obtenerListadoscitas(this.id)
      .subscribe( listadoscitas => {
        this.listaslistadoscitas = listadoscitas.map (l => {
          return {
            id: l.payload.doc.id,
            ...l.payload.doc.data()
          };
        });
      });
    }


    eliminarListado(listadocitas){
      this.bibliotecaService.eliminarListado(listadocitas);
    }

  }


