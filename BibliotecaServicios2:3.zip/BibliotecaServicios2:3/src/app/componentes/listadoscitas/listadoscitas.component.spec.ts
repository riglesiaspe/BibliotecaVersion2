import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadoscitasComponent } from './listadoscitas.component';

describe('ListadoscitasComponent', () => {
  let component: ListadoscitasComponent;
  let fixture: ComponentFixture<ListadoscitasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListadoscitasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadoscitasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
