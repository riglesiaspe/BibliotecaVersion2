import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderNaranjaComponent } from './header-naranja.component';

describe('HeaderNaranjaComponent', () => {
  let component: HeaderNaranjaComponent;
  let fixture: ComponentFixture<HeaderNaranjaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HeaderNaranjaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderNaranjaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
