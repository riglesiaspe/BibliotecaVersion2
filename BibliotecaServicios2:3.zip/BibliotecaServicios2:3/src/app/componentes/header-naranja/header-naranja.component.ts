import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-naranja',
  templateUrl: './header-naranja.component.html',
  styleUrls: ['./header-naranja.component.css']
})
export class HeaderNaranjaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
